#include <dirent.h>

int traverse(int datafd, int indexfd, int deletedfd);
