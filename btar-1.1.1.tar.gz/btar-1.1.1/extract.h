void extract(int fd, int outindex, int outdeleted);
