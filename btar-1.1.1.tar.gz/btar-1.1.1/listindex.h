void listindex(int fd);
